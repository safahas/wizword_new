"""
Word Guess Contest AI - Backend Package

This package contains the core game logic, word selection, and session management components.
"""

__version__ = "0.1.0" 